#include <iostream>
#include <stdexcept>
#include <fstream> // includere questa libreria!!!!
using namespace std;

int ricercaBinaria(int dim, int array[], int elem);
void letturaDaStream(ifstream &ifs, int dim, int a[]);
void letturaDaStdin(int dim, int a[]);
void stampa(int dim, int a[]);

